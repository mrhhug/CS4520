/**
 * 
 * 
 * 	Third stage for the batch execution simulation.
 * 
 * 	This adds the 'Main_body' code and the 'main'.
 * 	This is a runnable simulation, but produces almost no output.
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.batch3;