/**
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.distributions;