/**
 * 
 * 	Second stage.
 * 
 * 	This adds utility methods to the classes.
 * These are beyond the usual getters.
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.batch2;