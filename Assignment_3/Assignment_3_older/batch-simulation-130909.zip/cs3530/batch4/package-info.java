/**
 * 
 * 	Fourth stage for the batch execution simulation.
 * 
 * 	Trace output and analysis
 * 
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.batch4;