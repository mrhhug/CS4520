/**
 * 
 * 	First stages for the batch execution simulation.
 * 	
 * 	This has the classes with all instance and class fields
 * 	and constructors.
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.batch1;