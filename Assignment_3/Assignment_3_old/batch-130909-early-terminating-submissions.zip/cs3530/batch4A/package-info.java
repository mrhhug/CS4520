/**
 * 
 * 	Fourth stage for the batch execution simulation.
 * 
 * 	Trace output and analysis
 * 
 * 	Add cutoff to job submission
 * 
 * 
 */
/**
 * @author Ben
 *
 */
package cs3530.batch4A;