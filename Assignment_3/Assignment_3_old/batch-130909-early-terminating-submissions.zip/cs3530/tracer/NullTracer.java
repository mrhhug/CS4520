package cs3530.tracer;

public class NullTracer extends Tracer {

	/**
	 * Does nothing.
	 */
	@Override
	public void write(Object... parameters) {


	}

}
